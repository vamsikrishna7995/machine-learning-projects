# Machine Learning Projects

This repository contains three beginner‑friendly machine learning projects implemented in Python.  The projects were selected based on recommendations from the KDnuggets article “7 Beginner Machine Learning Projects To Complete This Weekend”, which suggests building practical applications covering different areas such as classification, natural language processing and computer vision【920597627124018†L72-L88】【920597627124018†L109-L123】.  Each project includes a short script and a README file explaining the context and how to run it.

| Project                            | Description | Key Concepts |
|-----------------------------------|-------------|-------------|
| **Titanic Survival Prediction** | Predict whether a passenger survived the RMS Titanic disaster using features like passenger class, age and gender.  The script loads a cleaned version of the Titanic dataset from Seaborn, preprocesses the data, trains logistic regression and decision tree models, and reports accuracy【920597627124018†L72-L88】. | Data cleaning, one‑hot encoding, logistic regression, decision tree |
| **Email Spam Classifier**       | Build a simple spam detector using a synthetic dataset of SMS‑like messages.  The KDnuggets article highlights this as a great introduction to natural language processing; in a full project you would use a larger corpus like the SMS Spam Collection or Enron email dataset【920597627124018†L109-L123】.  Here we tokenize messages with TF‑IDF and train a Multinomial Naive Bayes classifier. | Text preprocessing, TF‑IDF, naive Bayes |
| **Handwritten Digit Recognition** | Train a convolutional neural network (CNN) on the MNIST dataset to recognize handwritten digits.  Recognizing digits is a classic computer‑vision problem recommended for beginners and introduces concepts like image normalization and CNNs【920597627124018†L125-L140】. | Image normalization, CNNs, deep learning |

## Running the projects

Each project resides in its own subdirectory under `machine-learning-projects/` and contains a Python script and README.  To run a project, navigate to the corresponding directory and execute the script with Python.  For example, to run the Titanic survival prediction:

```bash
cd titanic_survival_prediction
python titanic_survival.py
```

Dependencies for all projects are listed in `requirements.txt`.  You can install them into a virtual environment with:

```bash
pip install -r requirements.txt
```

These examples are intentionally lightweight and focus on demonstrating core machine learning workflows.  For larger datasets or more advanced models, consider using the full datasets cited in the project READMEs.