"""
Handwritten digit recognition using a convolutional neural network (CNN).

This script trains a simple CNN on the MNIST dataset.  The MNIST problem is
highlighted by KDnuggets as an excellent project for beginners to learn about
computer vision and deep learning【920597627124018†L125-L140】.  CNNs are
particularly well‑suited for image data because they use convolution and
pooling layers to automatically extract features【920597627124018†L125-L139】.
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers


def load_and_preprocess_data():
    """Load the MNIST dataset and preprocess it.

    Returns
    -------
    (x_train, y_train), (x_test, y_test)
        Normalized training and test data and labels.
    """
    (x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()
    # Expand dimensions to (batch, height, width, channels)
    x_train = x_train[..., None].astype("float32") / 255.0
    x_test = x_test[..., None].astype("float32") / 255.0
    return (x_train, y_train), (x_test, y_test)


def build_model() -> keras.Model:
    """Build a simple CNN for digit classification.

    Returns
    -------
    model : keras.Model
        Compiled CNN model ready for training.
    """
    model = keras.Sequential(
        [
            layers.Conv2D(32, 3, activation="relu", input_shape=(28, 28, 1)),
            layers.MaxPooling2D(),
            layers.Conv2D(64, 3, activation="relu"),
            layers.MaxPooling2D(),
            layers.Flatten(),
            layers.Dense(128, activation="relu"),
            layers.Dense(10, activation="softmax"),
        ]
    )
    model.compile(
        optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"]
    )
    return model


def main() -> None:
    (x_train, y_train), (x_test, y_test) = load_and_preprocess_data()
    model = build_model()
    # Train the model for a few epochs; adjust epochs for demonstration purposes
    model.fit(x_train, y_train, epochs=3, batch_size=128, verbose=2)
    train_loss, train_acc = model.evaluate(x_train, y_train, verbose=0)
    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"Training accuracy: {train_acc:.3f}")
    print(f"Test accuracy: {test_acc:.3f}")


if __name__ == "__main__":
    main()