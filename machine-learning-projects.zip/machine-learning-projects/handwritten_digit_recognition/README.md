# Handwritten Digit Recognition

Recognizing handwritten digits is a classic computer‑vision problem.  The goal is to identify digits (0–9) from small grayscale images, usually using the **MNIST** dataset.  KDnuggets lists this as a recommended beginner project because it provides a practical introduction to image processing and deep learning【920597627124018†L125-L140】.  To solve the problem effectively you need to understand how to normalize image data and build a convolutional neural network (CNN), which automatically extracts spatial features from images【920597627124018†L125-L139】.

This example uses TensorFlow’s Keras API to load the MNIST dataset, define a simple CNN, train it for a few epochs and report its test accuracy.  The network contains two convolutional layers, max‑pooling, and a fully connected layer.

To run the script (this will download the MNIST dataset the first time):

```bash
python handwritten_digit_recognition.py
```

Training may take a couple of minutes depending on your CPU.  The script prints the training and test accuracy once training completes.  See the top‑level `requirements.txt` for dependencies.