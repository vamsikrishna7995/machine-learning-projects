# Email Spam Classifier

Automatically filtering spam is a fundamental problem in natural language processing.  Building an email spam classifier introduces concepts such as text preprocessing, feature extraction with term frequency–inverse document frequency (TF‑IDF), and training algorithms like **naive Bayes** and **support vector machines**.  KDnuggets recommends this project to beginners as a practical way to learn NLP basics【920597627124018†L109-L123】.

In a full‑scale project you would train on a large corpus such as the Enron dataset or the UCI SMS Spam Collection.  For demonstration purposes this repository includes a small synthetic dataset of short SMS‑like messages labeled as `spam` or `ham`.  The script shows how to transform raw text into numerical features using `scikit‑learn`’s `TfidfVectorizer`, train a **Multinomial Naive Bayes** classifier and evaluate its accuracy.

To run the script:

```bash
python email_spam_classifier.py
```

You should see the training and test accuracy printed in the console.  See the top‑level `requirements.txt` file for dependency versions.