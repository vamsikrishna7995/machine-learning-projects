"""
Simple email/SMS spam classifier using a synthetic dataset.

The KDnuggets article on beginner projects suggests building a spam classifier
to learn natural language processing techniques such as tokenization, TF–IDF
feature extraction and naive Bayes classification【920597627124018†L109-L123】.  In
real‑world scenarios you would use a larger corpus like the Enron or SMS Spam
Collection datasets; however, downloading external data is outside the scope
of this demonstration.  Instead we create a small synthetic dataset of
messages labelled as `spam` or `ham` (not spam) to illustrate the workflow.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score


def create_dataset():
    """Create a small synthetic SMS/email spam dataset.

    Returns
    -------
    messages : list[str]
        The SMS/email messages.
    labels : list[str]
        Corresponding labels ('spam' or 'ham').
    """
    spam_messages = [
        "Win a free cruise to the Bahamas! Call now.",
        "Congratulations, you've been selected to receive a $1000 gift card.",
        "URGENT! Your account has been suspended. Click here to reactivate.",
        "Get cheap meds online without prescription. Limited time offer.",
        "You've won a lottery! Claim your prize by sending your bank details.",
        "Act now! Exclusive deal on home insurance for today only.",
        "Dear user, your payment is due. Pay immediately to avoid penalties.",
        "This is not spam! Buy our product and get rich quick."
    ]
    ham_messages = [
        "Hey, are we still on for dinner tonight?",
        "Don't forget to pick up milk on your way home.",
        "Happy birthday! Hope you have a great day.",
        "Can you send me the meeting notes from yesterday?",
        "It was great seeing you last weekend. Let's catch up soon.",
        "Your Amazon package has shipped and will arrive tomorrow.",
        "Please review the attached document and let me know your thoughts.",
        "Thanks for your help with the project."
    ]
    messages = spam_messages + ham_messages
    labels = ["spam"] * len(spam_messages) + ["ham"] * len(ham_messages)
    return messages, labels


def main() -> None:
    # Create dataset
    messages, labels = create_dataset()
    # Split into training and test sets
    X_train, X_test, y_train, y_test = train_test_split(
        messages, labels, test_size=0.25, random_state=42, stratify=labels
    )
    # Convert text to TF–IDF features
    vectorizer = TfidfVectorizer(stop_words="english")
    X_train_tfidf = vectorizer.fit_transform(X_train)
    X_test_tfidf = vectorizer.transform(X_test)
    # Train Naive Bayes classifier
    clf = MultinomialNB()
    clf.fit(X_train_tfidf, y_train)
    # Evaluate
    train_pred = clf.predict(X_train_tfidf)
    test_pred = clf.predict(X_test_tfidf)
    train_acc = accuracy_score(y_train, train_pred)
    test_acc = accuracy_score(y_test, test_pred)
    print(f"Training accuracy: {train_acc:.3f}")
    print(f"Test accuracy: {test_acc:.3f}")


if __name__ == "__main__":
    main()