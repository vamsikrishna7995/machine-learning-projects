# Titanic Survival Prediction

This project demonstrates a simple binary classification task using the well‑known **Titanic** dataset.

Passengers on the RMS *Titanic* had varying probabilities of survival depending on factors such as their age, gender, and passenger class.  A classic beginner machine‑learning exercise is to predict whether a given passenger survived the disaster.  The *Titanic dataset* is considered one of the most accessible datasets for novices because it includes easy‑to‑understand columns like age, gender and class and a clear target variable (survived).  According to **KDnuggets**, this project teaches essential data preparation, data splitting and model evaluation skills【920597627124018†L72-L88】.

In this example we:

* Load the Titanic dataset from the `seaborn` library (a cleaned version of the Kaggle dataset).
* Perform basic preprocessing (drop rows with missing values and convert categorical variables via one‑hot encoding).
* Split the data into training and test sets.
* Train a **logistic regression** model and a **decision tree** classifier, two algorithms suggested for this problem【920597627124018†L72-L83】.
* Evaluate both models using accuracy on the test set.

To run the script, execute:

```bash
python titanic_survival.py
```

Requirements: see the top‑level `requirements.txt` for package versions.