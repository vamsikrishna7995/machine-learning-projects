"""
Titanic survival prediction using logistic regression and decision tree classifiers.

This script loads the Titanic dataset from Seaborn, performs basic preprocessing,
trains two models and prints their accuracies on a hold‑out test set.

The Titanic dataset used here is a cleaned version of the Kaggle Titanic competition data.
For more details on why this dataset is often recommended to beginners, see the
KDnuggets article on beginner machine‑learning projects【920597627124018†L72-L88】.
"""

import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score


def load_data() -> pd.DataFrame:
    """Load the Titanic dataset from seaborn.

    Returns
    -------
    df : pandas.DataFrame
        The Titanic dataset with columns such as 'survived', 'pclass', 'sex', 'age', etc.
    """
    df = sns.load_dataset("titanic")
    # Drop rows where the target is missing
    df = df.dropna(subset=["survived"])
    return df


def preprocess_and_split(df: pd.DataFrame):
    """Preprocess the dataset and split it into train and test sets.

    Parameters
    ----------
    df : pandas.DataFrame
        Raw Titanic dataset.

    Returns
    -------
    X_train, X_test : pandas.DataFrame
        Feature matrices for training and testing.
    y_train, y_test : pandas.Series
        Target vectors for training and testing.
    preprocessor : ColumnTransformer
        Fitted preprocessor for transforming new data.
    """
    # Select features and target
    features = ["pclass", "sex", "age", "sibsp", "parch", "fare", "embarked"]
    target = "survived"
    df = df[features + [target]].copy()
    # Drop rows with missing values
    df = df.dropna()
    X = df[features]
    y = df[target]
    # Identify categorical and numeric columns
    categorical_cols = ["sex", "embarked"]
    numeric_cols = [col for col in features if col not in categorical_cols]
    # Preprocessing: one‑hot encode categorical variables, pass numeric through unchanged
    preprocessor = ColumnTransformer(
        transformers=[
            ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
            ("num", "passthrough", numeric_cols),
        ]
    )
    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    return X_train, X_test, y_train, y_test, preprocessor


def train_and_evaluate(X_train, X_test, y_train, y_test, preprocessor):
    """Train logistic regression and decision tree models and evaluate them.

    Parameters
    ----------
    X_train, X_test, y_train, y_test : pd.DataFrame or pd.Series
        Training and test data.
    preprocessor : ColumnTransformer
        Preprocessor for transforming categorical variables.

    Returns
    -------
    results : dict
        Dictionary containing model names and their accuracies.
    """
    results = {}
    # Logistic Regression pipeline
    logreg = Pipeline(
        steps=[
            ("preprocess", preprocessor),
            ("model", LogisticRegression(max_iter=1000, solver="lbfgs")),
        ]
    )
    logreg.fit(X_train, y_train)
    y_pred_log = logreg.predict(X_test)
    results["Logistic Regression"] = accuracy_score(y_test, y_pred_log)
    # Decision Tree pipeline
    tree = Pipeline(
        steps=[
            ("preprocess", preprocessor),
            ("model", DecisionTreeClassifier(random_state=42)),
        ]
    )
    tree.fit(X_train, y_train)
    y_pred_tree = tree.predict(X_test)
    results["Decision Tree"] = accuracy_score(y_test, y_pred_tree)
    return results


def main() -> None:
    df = load_data()
    X_train, X_test, y_train, y_test, preprocessor = preprocess_and_split(df)
    results = train_and_evaluate(X_train, X_test, y_train, y_test, preprocessor)
    for model_name, acc in results.items():
        print(f"{model_name} accuracy: {acc:.3f}")


if __name__ == "__main__":
    main()